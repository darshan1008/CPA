#include <stdio.h>
#include <stdlib.h>
#include <math.h> 

int main(){
	double d = INFINITY;  

	printf("d = %lf\n", d); 

	return 0; 
}