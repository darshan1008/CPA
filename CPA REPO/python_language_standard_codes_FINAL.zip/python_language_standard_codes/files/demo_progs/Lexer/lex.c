int a float b char
int int main void
float double foo bar break
