#! /usr/bin/python3 

f = open ("lex.c") 

for line in f: 
    print (line)
