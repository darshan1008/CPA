L = [10, 20, 30, 40, -50, 60, -70, 80, -90, 100]

def f3(x): 

	if x < 0: 
		raise ValueError

def f2(x): 
	f3(x)

def f1(x): 
	f2(x)

i = 0
while i < 10: 

	try: 
		f1(L[i])
	except ValueError: 
		print(i, "Sorry for negative integer")

	i = i + 1