#! /usr/local/bin/python3 

def main (): 
    lst = [1,2,3,4,5] 
    try: 
        print (lst[9])
    except:
        print ("Error") 
    print ("LOL") 

main ()
