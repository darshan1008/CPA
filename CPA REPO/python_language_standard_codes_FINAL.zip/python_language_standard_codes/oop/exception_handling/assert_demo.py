import sys 

def main (): 

	n = int (input ("Enter integer:"))
	assert n != 0, "Divisor cannot be zero"
	

main () 