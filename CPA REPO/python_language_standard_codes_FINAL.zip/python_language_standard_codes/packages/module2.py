#! /usr/bin/python3 

import module1 as m
import sys 

def main ():
    
    m.f1 ()
    m.f2 () 
    m.f3 () 

    sys.exit ()

main ()
