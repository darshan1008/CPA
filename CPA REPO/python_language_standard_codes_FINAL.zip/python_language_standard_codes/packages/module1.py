#! /usr/bin/python3 


def f1 ():
    print ("module1:f1") 

def f2 ():
    print ("module2:f2") 

def f3 ():
    print ("module3:f3") 

