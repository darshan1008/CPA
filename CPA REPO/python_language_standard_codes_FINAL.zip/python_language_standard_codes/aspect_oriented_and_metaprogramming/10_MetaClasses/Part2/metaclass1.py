line = "-" * 65

class MetaOne(type):
    def __new__(meta, classname, supers, classdict):
        print (line, "__new__")
        
        print("ClassName:", classname)
        print("List of superclasses:") 
        for t in supers:
        	print(t.__name__)
        print("Class namespace is:")
        for name in classdict.keys():
        	print("Name:", name, "Value:", classdict[name])
        #classdict['PP'] = "SURPRISE!!"

        def handle_no_attr(self, name): 
        	if name == 'PP': 
        		self.__dict__[name] = 0 
        		return 0 
        	return None

        classdict['__getattr__'] = handle_no_attr


        print (line, "end __new__")
        if not 'meth' in classdict.keys(): 
            raise AttributeError("meth MUST be defined in class") 

        return type.__new__(meta, classname, supers, classdict)


class Eggs:
    pass

print('making class')
class Spam(Eggs, metaclass=MetaOne):      # Inherits from Eggs, instance of MetaOne
    data = 1                              # Class data attribute
    print("I AM HERE")
    def meth(self, arg):                  # Class method attribute
        return self.data + arg

print("type(Spam):", type(Spam)) 
print('making instance')
X = Spam()
print('data:', X.data, X.meth(2), X.PP)
print(X.__dict__)
print(Spam.__dict__)
print (line, "END OF PROGRAM")

