

@f
def g():
    st1
    st2
    st3



    stn 


f (ref_function)
===========================
FUNCTION
===========================
st1
st2
st3
st4
===========================

g = return (expr) - f  
