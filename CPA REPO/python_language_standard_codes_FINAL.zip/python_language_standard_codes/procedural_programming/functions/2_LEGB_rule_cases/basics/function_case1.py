#! /usr/bin/python3 

# Local X absent. Therefore, global X used 

X = 99 

def f1 ():
    print ("X:", X) 

f1 () 
