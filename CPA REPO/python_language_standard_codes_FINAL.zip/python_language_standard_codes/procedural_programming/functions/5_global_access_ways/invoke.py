#! /usr/bin/python3 

def main ():
    import global_access_ways
    global_access_ways.f1 ()
    global_access_ways.f2 ()
    global_access_ways.f3 ()
    global_access_ways.f4 ()
    
main ()
