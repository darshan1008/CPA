#! /usr/bin/python3 

def main ():
    while True:
        pass
main ()

