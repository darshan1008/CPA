#! /usr/bin/python3 

class Array: 
    def __init__ (self, d_type:type, a_size:int):
        
